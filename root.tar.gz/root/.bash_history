 poweroff
 poweroff
hostnamectl set-hostname TPServer
reboot
clear
cat /etc/debian_version
cp /etc/apt/sources.list /etc/apt/sources.list.bkp
vi /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt upgrade -y
apt full-upgrade -y
apt autoremove -y
apt clean
reboot
cat /etc/debian_version
apt full-upgrade -y
apt autoremove -y
reboot
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
vi /etc/ssh/sshd_config
clear
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
ls -l /root/.ss
ls -l /root/.ssh
vi /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
q
ls -l /root/.ssh
clear
apt install apache2 php libapache2-mod-php -y
systemctl status apache2
php -v
ls -l /root
find / -name index.php 2>/dev/null
find / -name logo.png 2>/dev/null
clear
ipconfig
clear
ip a
vi /etc/network/interfaces 
systemctl restart networking
reboot
vi /etc/network/interfaces
reboot
ip a
ping -c 3 8.8.8.8
ping -c 3 deb.debian.org
apt update
apt install mariadb-server -y
systemctl enable mariadb
systemctl start mariadb
systemctl status mariadb
ls -l /root/db.sql
vi /root/db.sql
mysql -u root
mysql -u root tp_integrador
mysql -u root tp_integrador 
vi /etc/network/interfaces
cat /etc/network/interfaces
reboot
ip a
cat /etc/network/interfaces
poweroff
exit
systemctl status ssh
ssh root@127.0.0.1
poweroff
exit
