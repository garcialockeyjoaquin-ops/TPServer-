#!/bin/bash

if [ "$1" = "-help" ]; then
	echo "uso:"
	echo "/opt/scripts/backup_full.sh ORIGEN DESTINO"
	echo "Ejemplo:"
	echo "/opt/scripts/backup_full.sh /www_dir /backup_dir"
	echo "/opt/scripts/backup_full.sh /var/log /backup_dir"
	exit 0
fi

if [ $# -ne 2 ]; then
	echo "Error: debe ingresar origen y destino"
	exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

if [ ! -d "$ORIGEN" ]; then
	echo "Error: el origen no existe"
	exit 3
fi

tar -czf "$DESTINO/$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"

	echo "Backup generado:"
	echo "$DESTINO/$ARCHIVO"

