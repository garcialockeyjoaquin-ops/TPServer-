<?php
echo "<h1>TP Integrador - Servidor Apache con PHP</h1>";
echo "<p>Servidor: TPServer</p>";
echo "<p>PHP funcionando correctamente.</p>";
echo "<img src="logo.png" width="200">";
?>
