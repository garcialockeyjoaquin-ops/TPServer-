CREATE TABLE alumnos (
	id INT AUTO_INCREMENT PRIMARY KEY,
	nombre VARCHAR(50),
	apellido VARCHAR(50)
);

INSERT INTO alumnos (nombre, apellido)
VALUES ("Joaquin", "Garcia", "Lockey");

CREATE TABLE servicios (
	id INT AUTO_INCREMENT PRIMARY KEY,
	nombre VARCHAR(50),
	estado VARCHAR(50)
);

INSERT INTO servicios (nombre, estado)
VALUES ("Apache", "activo"),
	("PHP", "activo"),
	("MariaDB", "activo"),
	("SSH, "activo");
